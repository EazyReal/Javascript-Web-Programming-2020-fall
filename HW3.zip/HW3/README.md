# JavaScript Web Programming 2020 fall HW 3

## Information
- author
    - National Chiao Tung University 0712238 Yan-Tong Lin
- description
    - `JS web programming 2020 fall HW 3`
    - number guessing game based on binary representation
- usage
    - directly open the hw3.html in the current directory
- license
    - Apache 2.0
- notice
    - this work is done by NCTU 0712238 Yan-Tong Lin @ 2020/10/27, please explicitly show this notice when using any part of this code

## Implementation
- use wrapper and CSS grid to do the formatting
- `onclick`, use `alert` to show the corresponding answer with `checked` values of `checkboxes`
