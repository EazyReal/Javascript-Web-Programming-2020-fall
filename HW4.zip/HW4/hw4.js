/*
{
    author : National Chiao Tung University 0712238 Yan-Tong Lin,
    description :  JS web programming 2020 fall HW 3,
    usage : directly open the hw3.html in the current directory,
    license: Apache 2.0,
    notice: this work is done by NCTU 0712238 Yan-Tong Lin @ 2020/10/27, please explicitly refer to this when using a part of this code,
}
*/

/* JS-1
function Shape(name, sides, sideLength)
{
    this.name = name;
    this.sides = sides;
    this.sideLength = sideLength;
}
*/

class Shape
{
    constructor(name, sides, sideLength)
    {
        this.name = name;
        this.sides = sides;
        this.sideLength = sideLength;
    }
    calcPerimeter()
    {
        console.log(this.name + "'s perimeter = " + this.sides*this.sideLength);
    }
}

class Square extends Shape
{
    constructor(sideLength)
    {
        super("square", 4, sideLength);
    }
    calcArea()
    {
        console.log(this.name + "'s area = " + this.sideLength*this.sideLength);
    }
}

// Write your code below here

Shape.prototype.calcPerimeter = function()
{
    console.log(this.name + "'s perimeter = " + this.sides*this.sideLength);
}

var square = new Shape("square", 4, 5);
var triangle = new Shape("triangle", 3, 3);
var square2 = new Square(5);

square.calcPerimeter();
triangle.calcPerimeter();
square2.calcPerimeter();
square2.calcArea();


